<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Id), array('view', 'id'=>$data->Id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdUsuario')); ?>:</b>
	<?php echo CHtml::encode($data->IdUsuario); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('uno')); ?>:</b>
	<?php echo CHtml::encode($data->uno); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('dos')); ?>:</b>
	<?php echo CHtml::encode($data->dos); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('dos_uno')); ?>:</b>
	<?php echo CHtml::encode($data->dos_uno); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tres')); ?>:</b>
	<?php echo CHtml::encode($data->tres); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tres_uno')); ?>:</b>
	<?php echo CHtml::encode($data->tres_uno); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('cuatro')); ?>:</b>
	<?php echo CHtml::encode($data->cuatro); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('cuatro_uno')); ?>:</b>
	<?php echo CHtml::encode($data->cuatro_uno); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('cinco')); ?>:</b>
	<?php echo CHtml::encode($data->cinco); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('seis')); ?>:</b>
	<?php echo CHtml::encode($data->seis); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('siete')); ?>:</b>
	<?php echo CHtml::encode($data->siete); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ocho')); ?>:</b>
	<?php echo CHtml::encode($data->ocho); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nueve')); ?>:</b>
	<?php echo CHtml::encode($data->nueve); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('diez')); ?>:</b>
	<?php echo CHtml::encode($data->diez); ?>
	<br />
<<<<<<< HEAD

	<b><?php echo CHtml::encode($data->getAttributeLabel('IdPais')); ?>:</b>
	<?php echo CHtml::encode($data->IdPais); ?>
	<br />

	*/ ?>

=======
>>>>>>> 3e10e8c595248dc8f1428b7999ab365742db4674
</div>