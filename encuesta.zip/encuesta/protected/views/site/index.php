<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>
<br/>
<h1><i>¡Bienvenido!</h1><br/>

<p><b><big>A la encuesta que busca la determinar las necesidades de los clientes para la creación de un software que coadyuve  a la construcción de la Política de un Sistema de Gestión de la Seguridad de la Información S.G.S.I. </b></i></big></p><br/>
<p>Duración de la encuesta 2 a 3 minutos.</p>
<p>Cantidad de preguntas: 10 (Diez).</p><br/>
<p><big>Para diligenciar la encuesta, regístrate de forma rápida haciendo clic <a href="http://localhost/encuesta/index.php?r=usuario/create">aquí.</a></big></p><br/>
<p><small>Para detalles de esta  <a href="http://www.yiiframework.com/doc/">documentación.</a>
Preguntas y dudas en el <a href="http://www.yiiframework.com/forum/">foro.</a></small></p>
