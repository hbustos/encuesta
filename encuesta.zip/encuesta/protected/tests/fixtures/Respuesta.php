<?php

return array(
	/*
	'sample1'=>array(

Warning: Invalid argument supplied for foreach() in C:\xampp\htdocs\yii\framework\cli\views\shell\model\fixture.php on line 13
	),
	'sample2'=>array(

Warning: Invalid argument supplied for foreach() in C:\xampp\htdocs\yii\framework\cli\views\shell\model\fixture.php on line 19
	),
	*/
);
