<?php

return array(
	/*
	'sample1'=>array(
		'Nombres' => '',
		'Apellidos' => '',
		'CorreoElectronico' => '',
	),
	'sample2'=>array(
		'Nombres' => '',
		'Apellidos' => '',
		'CorreoElectronico' => '',
	),
	*/
);
