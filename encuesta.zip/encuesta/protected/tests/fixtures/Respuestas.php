<?php

return array(
	/*
	'sample1'=>array(
		'IdUsuario' => '',
		'uno' => '',
		'dos' => '',
		'dos_uno' => '',
		'tres' => '',
		'tres_uno' => '',
		'cuatro' => '',
		'cuatro_uno' => '',
		'cinco' => '',
		'seis' => '',
		'siete' => '',
		'ocho' => '',
		'nueve' => '',
		'diez' => '',
		'IdPais' => '',
	),
	'sample2'=>array(
		'IdUsuario' => '',
		'uno' => '',
		'dos' => '',
		'dos_uno' => '',
		'tres' => '',
		'tres_uno' => '',
		'cuatro' => '',
		'cuatro_uno' => '',
		'cinco' => '',
		'seis' => '',
		'siete' => '',
		'ocho' => '',
		'nueve' => '',
		'diez' => '',
		'IdPais' => '',
	),
	*/
);
