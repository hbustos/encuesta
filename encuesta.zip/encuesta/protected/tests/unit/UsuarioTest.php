<?php

class UsuarioTest extends CDbTestCase
{
	public $fixtures=array(
		'usuarios'=>'Usuario',
	);

	public function testCreate()
	{

	}
}