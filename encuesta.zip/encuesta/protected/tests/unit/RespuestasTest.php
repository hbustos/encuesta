<?php

class respuestasTest extends CDbTestCase
{
	public $fixtures=array(
		'respuestases'=>'respuestas',
	);

	public function testCreate()
	{

	}
}