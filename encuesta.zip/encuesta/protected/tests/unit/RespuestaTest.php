<?php

class RespuestaTest extends CDbTestCase
{
	public $fixtures=array(
		'respuestas'=>'Respuesta',
	);

	public function testCreate()
	{

	}
}