<?php

class PaisTest extends CDbTestCase
{
	public $fixtures=array(
		'paises'=>'Pais',
	);

	public function testCreate()
	{

	}
}